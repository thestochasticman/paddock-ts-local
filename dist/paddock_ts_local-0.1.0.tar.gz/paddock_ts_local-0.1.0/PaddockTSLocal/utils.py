import pickle

load_pickle = lambda path: pickle.load(open(path, 'rb'))



